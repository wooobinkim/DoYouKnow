-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 43.201.37.208    Database: DoYouKnow
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dykclub_content`
--

DROP TABLE IF EXISTS `dykclub_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dykclub_content` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `dykclub_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjcwmjn5wkq6w20c6si19jg0ry` (`dykclub_id`),
  CONSTRAINT `FKjcwmjn5wkq6w20c6si19jg0ry` FOREIGN KEY (`dykclub_id`) REFERENCES `dykclub` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dykclub_content`
--

LOCK TABLES `dykclub_content` WRITE;
/*!40000 ALTER TABLE `dykclub_content` DISABLE KEYS */;
INSERT INTO `dykclub_content` VALUES (1,'대한민국 국적의 토트넘 홋스퍼 FC 소속 축구선수. 주 포지션은 윙어이며, 현재 대한민국 축구 국가대표팀 주장을 맡고 있다.','introduce',1),(2,'대한민국의 前 피겨 스케이팅 선수로 2010 밴쿠버 동계올림픽 피겨 스케이팅 여자 싱글 금메달리스트, 2014 소치 동계올림픽 피겨 스케이팅 여자 싱글 은메달리스트이다.','introduce',2),(3,'대한민국 국적의 배구 선수이다. 포지션은 아웃사이드 스파이커. 세계적인 배구 선수 중 한 명으로 88년생이라는 적지 않은 나이에도 정상의 자리를 굳건히 지키고 있는 대한민국 여자배구계의 스타 선수다.','introduce',3),(4,'천재적인 두뇌와 자폐스펙트럼을 동시에 가진 신입 변호사 우영우의 대형 로펌 생존기','introduce',4),(5,'낯선 땅 극한의 환경 속에서 사랑과 성공을 꿈꾸는 젊은 군인과 의사들을 통해 삶의 가치를 담아내어, 유럽의 발칸 반도에 위치한 가상 국가 우르크를 배경으로 하는 블록버스터급 휴먼 멜로 드라마','introduce',5),(6,'2021년 넷플릭스에서 방영한 대한민국의 액션 서스펜스 생존 드라마이다. 9화로 구성되며 황동혁이 각본과 감독을 맡았다. 이정재, 박해수, 위하준, 정호연, 오영수, 허성태, 아누팜 트리파티, 김주령, 이유미, 이병헌, 공유 등이 출연했다.','introduce',6),(7,'2019년에 개봉한 봉준호 감독의 7번째 장편 영화. 상류층과 하류층, 두 가족의 만남을 다룬 대한민국의 블랙 코미디 가족 드라마 영화이다.','introduce',7),(8,'동명의 만화를 원안으로 한 박찬욱 감독, 최민식, 유지태, 강혜정 주연의 스릴러 영화','introduce',8),(9,'2016년 개봉한 한국의 좀비 영화. 미확인 바이러스 감염자들이 발생한 아비규환 속의 부산행 KTX에서 벌어지는 이야기다. 애니메이션을 만들어왔던 연상호감독이 처음으로 만든 실사 영화이며, 한국 최초의 좀비 블록버스터이다','introduce',9),(10,'2013년 데뷔해 국내외 신인상을 휩쓴 방탄소년단은 명실상부 한국을 대표하는 최정상 보이 그룹으로 성장했다. 전 세계적으로 방탄소년단 열풍을 일으키며 ‘21세기 팝 아이콘’으로 불린다.','introduce',10),(11,'대한민국의 가수, 작곡가, 댄서, 프로듀서. P NATION의 설립자 겸 사내이사를 맡고 있다.\'강남스타일\' 뮤직비디오는 2005년 유튜브가 생긴 이래 처음으로 단일 영상 유튜브 조회수 10억뷰와 20억뷰를 달성했다.','introduce',11),(12,'2021년 넷플릭스 오징어 게임이 세계적으로 돌풍을 일으키면서 세계적인 배우 중 하나로 거듭났다. 미국 배우 조합상에선 물론 인디펜던트 스피릿 어워즈와 크리틱스 초이스 시상식에서 한국인 최초로 남우주연상을 모두 수상했고, 에미상 시상식에서 드라마시리즈 남우주연상을 수상했다.','introduce',12);
/*!40000 ALTER TABLE `dykclub_content` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07 10:52:16
