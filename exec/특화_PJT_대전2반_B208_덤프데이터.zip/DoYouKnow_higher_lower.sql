-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 43.201.37.208    Database: DoYouKnow
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `higher_lower`
--

DROP TABLE IF EXISTS `higher_lower`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `higher_lower` (
  `name` varchar(255) NOT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  `count` bigint DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `higher_lower`
--

LOCK TABLES `higher_lower` WRITE;
/*!40000 ALTER TABLE `higher_lower` DISABLE KEYS */;
INSERT INTO `higher_lower` VALUES ('강태오','Game/2b2bf90c-6a01-49f6-9530-9698ecd2ec92강태오.jpg',NULL),('고경표','Game/73d1a5d7-1b24-48a2-9998-823c0b48a13e고경표.jfif',NULL),('공조','Game/aa7be7fb-aa5d-486b-b081-1b32c9d0ab64공조.jpg',NULL),('공효진','Game/5cad97ad-c337-45ff-a016-96a60cec6361공효진.jpg',NULL),('괴물','Game/c6ec959c-419d-4dd4-8aea-f688995dcc8e괴물.jpg',NULL),('금수저','Game/0cba25c0-e747-4bbd-b21b-d10fdd474726금수저.jfif',NULL),('기생충','Game/e5d230bf-85b5-4532-92bf-582eb0e5ed6a기생충.jpg',NULL),('김고은','Game/0107046b-3993-4c92-afa7-554ba0a6fa78김고은.jfif',NULL),('김민재','Game/d690ded1-ba6a-4783-b6e8-56ba4b244f6d김민재.jfif',NULL),('김선호','Game/0e205ecb-85de-4eba-a82f-97dc5e98efea김선호.jpg',NULL),('김세정','Game/4e55cac5-c7e1-4a1e-b423-ee1f33faea1b김세정.jpg',NULL),('김수현','Game/d4b9d2d5-d8a6-416d-a7a0-a10f9af670f0김수현.jpg',NULL),('김우빈','Game/c6d98437-398d-49be-8b3a-b6e5555e19b4김우빈.jpg',NULL),('김재중','Game/4395da6a-84c6-46dd-ac62-7fbab59c6396김재중.jpg',NULL),('김태리','Game/b9a5c48b-1a3f-4b5e-a7bc-c1ed0cb9f885김태리.jpg',NULL),('남궁민','Game/ae6e9a50-e661-4680-9165-534b8c5cc0f3남궁민.jfif',NULL),('남주혁','Game/9ffe128e-b41c-499a-9ad1-4ec644aac472남주혁.jpg',NULL),('남지현','Game/ef91b5e5-2332-46c2-8dce-33b7807f590c남지현.jpg',NULL),('넷플릭스','Game/137777cb-a71b-4925-8b9a-137ddd7afefc넷플릭스.jpg',NULL),('다니엘헤니','Game/f7fe2c74-aa38-464e-913c-32c1c329fee8다니엘헤니.jpg',NULL),('도깨비','Game/ec779cee-c757-49b3-a0da-6e7808deb05e도깨비.jfif',NULL),('동방신기','Game/9f4af600-24b9-4fa3-a5c7-5f93a342d088동방신기.jfif',NULL),('레드벨벳','Game/eff306de-baca-4b3d-8764-2e17a5396429레드벨벳.jfif',NULL),('류준열','Game/d88d6e75-d0b4-49ae-a20f-a62cf0a86c42류준열.jpg',NULL),('마녀','Game/000b81f2-833c-48ea-b9b1-97218618d0e6마녀.jfif',NULL),('마약왕','Game/639de028-f18f-4e72-ad28-f288542dc7ec마약왕.jfif',NULL),('미스터선샤인','Game/c23296a1-abd6-4aa8-8a00-584bc76775e1미스터선샤인.jpg',NULL),('박민영','Game/88dd35c2-a7a7-4a28-9cf6-11e4d09a9d13박민영.jfif',NULL),('박보검','Game/496572d4-c4a3-4d2b-af87-2603604c06e1박보검.jfif',NULL),('박서준','Game/9ef465a3-38d7-4848-a6b5-c933b9a33747박서준.jpg',NULL),('박은빈','Game/755b1f1a-4f13-4984-a539-c83a61536e84박은빈.jpg',NULL),('박지후','Game/d149842c-6a0c-4973-95a0-72978564ddf0박지후.jpg',NULL),('박해수','Game/70c36c4d-7e30-43d0-8fc9-ed5bfff490ec박해수.jpg',NULL),('박효신','Game/28fec966-5bff-4780-b4fc-951fce8bb657박효신.jpg',NULL),('방탄소년단','Game/a2a95299-2e11-4c24-a34c-ac9b2934a0ab방탄소년단.jpg',NULL),('범죄','Game/766b25ce-ebdd-4f0b-b6b6-6ba6c6322b11범죄.jpg',NULL),('범죄도시','Game/596aa7a2-7d5f-4da9-8958-5f1d1f5f95db범죄도시.jpg',NULL),('봉준호','Game/136e8da5-e5aa-46f3-a764-16847915b071봉준호.jpg',NULL),('뷔','Game/31bacdce-cef5-4092-969b-d051c8be564d뷔.jpg',NULL),('빅마우스','Game/784fea87-291a-4e8a-b6fe-f24dc1cc3313빅마우스.jpg',NULL),('사랑의불시착','Game/1c105a78-2899-41cf-bcd1-c7f06df3bb50사랑의불시착.jpg',NULL),('샤이니','Game/8c788bd4-69da-4a0b-93ac-577adab83b55샤이니.jpg',NULL),('소녀시대','Game/a397af92-ae71-46e0-b32e-d6a3ecbcf83a소녀시대.jpg',NULL),('소지섭','Game/685c598d-3dc2-41ed-b572-c5c22ef26a1c소지섭.jfif',NULL),('손예진','Game/37d0464f-40be-4372-9d82-42589aa93687손예진.jpg',NULL),('손흥민','Game/3b8db870-e57e-4527-8779-ef945afd8cfb손흥민.jfif',NULL),('송강','Game/a6e9406e-de2d-451e-8f1f-8777e2d8fb04송강.jpg',NULL),('송중기','Game/8bccd3ab-f487-4461-9873-c0f60a87ef2b송중기.jpg',NULL),('송혜교','Game/75174dac-4abd-4144-ace8-46ac697499fb송혜교.jfif',NULL),('수리남','Game/bcaf6d5a-4fb7-4041-8354-2e1970fb4a40수리남.jfif',NULL),('스위트홈','Game/9d5157db-db64-48f3-b058-0d183d7806f5스위트홈.jpg',NULL),('스토브리그','Game/4456bdcb-16b7-49c6-98a5-4ce0566fefd3스토브리그.jfif',NULL),('슬기로운의사생활','Game/69f79808-037b-4946-a2f6-de8c43100a81슬기로운의사생활.jfif',NULL),('시그널','Game/d6247b6e-d3eb-4b78-8fd8-4c54283e98f7시그널.jfif',NULL),('시우민','Game/01429e4c-073a-482f-a189-3f09f8712127시우민.jpg',NULL),('신민아','Game/cff7989c-c3d9-4798-a618-dfb686c724c1신민아.jpg',NULL),('씨엔블루','Game/0c0faaa5-f162-4301-875e-eb0582acd0c1씨엔블루.webp',NULL),('아가씨','Game/d766c022-241c-4f6a-bc8d-75eb9a31012d아가씨.jpg',NULL),('아이유','Game/798de469-297c-4261-9d27-61a02e888c77아이유.jpg',NULL),('안보현','Game/ff6555ce-89a2-48e7-a454-0c8dc83f8302안보현.jpg',NULL),('암살','Game/faed4d11-2f2e-402e-ba80-12b4f5c34a86암살.jpg',NULL),('에미상','Game/f00a4306-904c-4078-a68c-3d68aaae1a63에미상.jpg',NULL),('엑소','Game/15af4533-28e4-4925-be73-b756ebaf4a13엑소.jpg',NULL),('연모','Game/ed311ff3-7d55-45aa-9dc8-7a5a3925c25b연모.jfif',NULL),('오징어게임','Game/902381ad-2a1e-43f7-b976-bbe2e427d244오징어게임.jpg',NULL),('온유','Game/3a09b293-1307-4acf-8167-623536e2e73c온유.png',NULL),('외계인','Game/d7076236-95b2-42a1-824f-2ce3c9732717외계인.jfif',NULL),('용의자','Game/f0e21341-c2f7-4fc8-8b95-4be62542dbf4용의자.jfif',NULL),('우변호사','Game/2ca0690e-a654-4320-ae52-e09832552d76우변호.jpg',NULL),('우영우','Game/aeb5887c-7f5a-46de-9087-38bc2f6c303e우영우.jpg',NULL),('웹툰','Game/c66565c9-b8f3-4666-902b-9f8b4de1333e웹툰.png',NULL),('윤아','Game/c4c08c2d-a6ba-49a6-b229-ccd59f6df935윤아.jpg',NULL),('응답하라','Game/6cfc1541-9dcd-4ebb-b8e1-75f9894c73fd응답하라.jfif',NULL),('이민호','Game/e9dc4d3e-b3d2-4695-a9a3-8ccfcb0cc101이민호.jpg',NULL),('이세영','Game/755d077d-f4f5-4367-a255-6a0debdaf4c8이세영.jpg',NULL),('이정재','Game/be00d66e-8ea0-4f69-9842-00f152fa032e이정재.jpg',NULL),('이종석','Game/0e8ff59f-76b4-4ff5-bca1-4f3d2035ab14이종석.png',NULL),('이태원클라쓰','Game/aa30598d-e893-4b33-b543-06614ed9eefb이태원클라쓰.jpg',NULL),('작은아씨들','Game/f3b64503-aa77-4252-acd2-e74d0dbe3e50작은아씨들.jfif',NULL),('제이홉','Game/c3bd1e39-8c2c-4f33-a5a1-81e17cf175b2제이홉.jpg',NULL),('준호','Game/d311d293-c170-457c-bd61-7d76ab8d2e13준호.jfif',NULL),('지옥','Game/4f77254a-4f0c-4c43-8c1a-f4a672950fce지옥.jfif',NULL),('지창욱','Game/5ce4fe25-cbfd-4057-a458-562e755fcfef지창욱.jpg',NULL),('차은우','Game/39af8db2-d7a8-451a-ad48-633ed9564c3c차은우.jpg',NULL),('코로나','Game/ce8000f2-98d3-49c2-9389-342b062c2c14코로나.png',NULL),('킹덤','Game/73038dd8-526a-4527-8984-e2e5510efbce킹덤.jfif',NULL),('태양의후예','Game/69397a66-debb-49b6-b1c3-7b32d437f2ee태양의후예.png',NULL),('택시운전사','Game/c815f223-9891-43e4-a0e5-8d1e78770e3d택시운전사.jpg',NULL),('트와이스','Game/8e4bb144-05c6-4480-840d-c5ccbffceb13트와이스.jpg',NULL),('펜트하우스','Game/f6abda55-0d9c-4a6c-891e-f0c0dae2959b펜트하우스.jpg',NULL),('하정우','Game/09321815-fb74-495d-b565-8b72e0f8c58a하정우.jpg',NULL),('현빈','Game/e16bf8b7-6af9-4fa0-b0c8-6c40f7472329현빈.jfif',NULL),('호텔델루나','Game/c501c81f-f03b-41c9-8ac0-64a2bae58385호텔델루나.jfif',NULL),('황동혁','Game/0ae84626-f6c4-4a2c-8d2f-240b6772e25c황동혁.jpg',NULL),('황정민','Game/dc7e3adf-7836-4171-9efc-ce020c6df1d8황정민.jfif',NULL);
/*!40000 ALTER TABLE `higher_lower` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07 10:52:13
